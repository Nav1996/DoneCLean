package com.example.android.employeesmanagementsoftware.Cleaner;

public class Cleaner {
    private String name;
    private String nic;
    private String cid;
    private String email;
    private String contact_no;

    public Cleaner(String name, String nic, String cid, String email, String contact_no) {
        this.name = name;
        this.nic = nic;
        this.cid = cid;
        this.email = email;
        this.contact_no = contact_no;
    }
}
